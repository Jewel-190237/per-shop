import Banner from "../Product/Banner";
import OurCard from "./OurCard";


const OurShop = () => {
    return (
        <div>
           <Banner></Banner> 
           <OurCard></OurCard>

        </div>
    );
};

export default OurShop;