
import Banner from "../Banner";
import PuppiesCard from "./PuppiesCard";


const PuppiesProduct = () => {
    return (
        <div>
           <Banner></Banner> 
          
           <PuppiesCard></PuppiesCard>
        </div>
    );
};

export default PuppiesProduct;