import './App.css'

function App() {


  return (
    <>  
      <h1>Vite + React</h1>
      
    </>
  )
}

export default App
